export default function AdPlaceholder({ slot = "horizontal", style = {} }) {
  const sizes = {
    horizontal: { width: "100%", height: "90px" },
    sidebar: { width: "100%", height: "250px" },
    inFeed: { width: "100%", height: "120px" },
    inArticle: { width: "100%", height: "100px" },
  };

  return (
    <div
      className="ad-placeholder"
      style={{
        ...sizes[slot],
        ...style,
      }}
    >
      <span>Advertisement</span>
      {/* Replace with actual AdSense code: 
          <ins class="adsbygoogle"
               style="display:block"
               data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
               data-ad-slot="XXXXXXXXXX"
               data-ad-format="auto"
               data-full-width-responsive="true"></ins>
          <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
      */}
    </div>
  );
}
