import { Link } from "react-router-dom";
import { Download, Clock, Tag } from "lucide-react";
import { getCategoryById } from "../data/bundles";

export default function BundleCard({ bundle }) {
  const category = getCategoryById(bundle.categoryId);

  return (
    <article className="bundle-card">
      <div
        className="bundle-card-banner"
        style={{
          background: `linear-gradient(135deg, ${category.color}dd, ${category.color}88)`,
        }}
      >
        <span className="bundle-card-icon">{category.icon}</span>
        <span className="bundle-card-count">{bundle.count} Reels</span>
      </div>
      <div className="bundle-card-body">
        <div className="bundle-card-meta">
          <span className="bundle-card-category">
            <Tag size={12} /> {category.name}
          </span>
          <span className="bundle-card-date">
            <Clock size={12} />{" "}
            {new Date(bundle.date).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </span>
        </div>
        <h3 className="bundle-card-title">{bundle.title}</h3>
        <p className="bundle-card-desc">{bundle.description}</p>
        <div className="bundle-card-actions">
          <Link to={`/bundle/${bundle.slug}`} className="btn btn-primary btn-sm">
            Read More
          </Link>
          <a
            href={bundle.downloadUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-download btn-sm"
          >
            <Download size={14} /> Download
          </a>
        </div>
      </div>
    </article>
  );
}
