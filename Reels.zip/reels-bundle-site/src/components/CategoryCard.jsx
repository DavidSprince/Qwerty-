import { Link } from "react-router-dom";
import { getBundlesByCategory } from "../data/bundles";

export default function CategoryCard({ category }) {
  const count = getBundlesByCategory(category.id).length;

  return (
    <Link
      to={`/category/${category.id}`}
      className="category-card"
      style={{
        "--cat-color": category.color,
      }}
    >
      <div
        className="category-card-icon"
        style={{ background: `${category.color}22` }}
      >
        <span>{category.icon}</span>
      </div>
      <div className="category-card-info">
        <h3>{category.name}</h3>
        <p>{count} bundle{count !== 1 ? "s" : ""}</p>
      </div>
      <div className="category-card-arrow">→</div>
    </Link>
  );
}
