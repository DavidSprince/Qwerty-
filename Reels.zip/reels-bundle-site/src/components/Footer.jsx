import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-grid">
          <div className="footer-col">
            <h3>📦 ReelsBundle</h3>
            <p>
              The largest collection of copyright-free reels and shorts bundles
              for social media content creators. Download and grow your pages
              instantly.
            </p>
          </div>
          <div className="footer-col">
            <h4>Quick Links</h4>
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/categories">Categories</Link>
              </li>
              <li>
                <Link to="/bundles">All Bundles</Link>
              </li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Popular Categories</h4>
            <ul>
              <li>
                <Link to="/category/motivational">Motivational</Link>
              </li>
              <li>
                <Link to="/category/islamic">Islamic</Link>
              </li>
              <li>
                <Link to="/category/cars">Cars</Link>
              </li>
              <li>
                <Link to="/category/anime">Anime</Link>
              </li>
            </ul>
          </div>
          <div className="footer-col">
            <h4>Connect</h4>
            <a
              href="https://t.me/bekingvipu"
              target="_blank"
              rel="noopener noreferrer"
              className="telegram-btn footer-telegram"
            >
              Join Telegram Channel
            </a>
            <p className="footer-note">
              Follow us on Telegram for exclusive bundles, updates, and early
              access to new content.
            </p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>© 2025 ReelsBundle. All rights reserved. All content is copyright-free.</p>
          <p className="disclaimer">
            Disclaimer: All bundles are provided for free via Google Drive. We do
            not host any files. Content is shared for educational and content
            creation purposes.
          </p>
        </div>
      </div>
    </footer>
  );
}
