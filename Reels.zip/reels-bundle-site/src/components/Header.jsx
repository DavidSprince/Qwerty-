import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Download, Search } from "lucide-react";

export default function Header({ onSearch }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const location = useLocation();

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearchTerm(val);
    onSearch(val);
  };

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/categories", label: "Categories" },
    { to: "/bundles", label: "All Bundles" },
  ];

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="logo">
          <Download size={28} />
          <span>ReelsBundle</span>
        </Link>

        <nav className={`nav ${menuOpen ? "nav-open" : ""}`}>
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`nav-link ${
                location.pathname === link.to ? "active" : ""
              }`}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="header-actions">
          <button
            className="search-toggle"
            onClick={() => setSearchOpen(!searchOpen)}
          >
            <Search size={20} />
          </button>
          <a
            href="https://t.me/bekingvipu"
            target="_blank"
            rel="noopener noreferrer"
            className="telegram-btn"
          >
            Join Telegram
          </a>
          <button
            className="menu-toggle"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {searchOpen && (
        <div className="search-bar">
          <div className="search-bar-inner">
            <Search size={20} />
            <input
              type="text"
              placeholder="Search bundles..."
              value={searchTerm}
              onChange={handleSearch}
              autoFocus
            />
          </div>
        </div>
      )}
    </header>
  );
}
