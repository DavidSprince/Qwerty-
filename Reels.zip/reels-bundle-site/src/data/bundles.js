export const categories = [
  {
    id: "motivational",
    name: "Motivational",
    icon: "💪",
    color: "#FF6B35",
    description:
      "Inspiring and powerful motivational reels to boost your social media presence. Perfect for Instagram, YouTube Shorts, and TikTok.",
  },
  {
    id: "islamic",
    name: "Islamic",
    icon: "🕌",
    color: "#1B998B",
    description:
      "Beautiful Islamic content reels including Quran verses, reminders, and spiritual content for your audience.",
  },
  {
    id: "art-craft",
    name: "Art & Craft",
    icon: "🎨",
    color: "#E63946",
    description:
      "Stunning art and craft reels showcasing creative processes, DIY projects, and artistic inspiration.",
  },
  {
    id: "wwe",
    name: "WWE & Wrestling",
    icon: "🤼",
    color: "#7B2D8E",
    description:
      "High-energy WWE wrestling reels featuring epic moments, highlights, and viral wrestling content.",
  },
  {
    id: "anime",
    name: "Anime & 2D Animation",
    icon: "🎌",
    color: "#FF006E",
    description:
      "Trending anime reels and 2D animation shorts that captivate audiences worldwide.",
  },
  {
    id: "fitness",
    name: "Fitness",
    icon: "🏋️",
    color: "#2EC4B6",
    description:
      "Fitness and workout reels to motivate your audience. From gym routines to healthy lifestyle content.",
  },
  {
    id: "cars",
    name: "Cars & Automobiles",
    icon: "🏎️",
    color: "#0077B6",
    description:
      "Mega car edit reels and automotive content that drives engagement on your social media.",
  },
  {
    id: "aesthetic",
    name: "Aesthetic",
    icon: "✨",
    color: "#C77DFF",
    description:
      "Aesthetic and visually stunning reels perfect for lifestyle and mood-based content creators.",
  },
  {
    id: "cricket",
    name: "Cricket",
    icon: "🏏",
    color: "#2D6A4F",
    description:
      "Cricket reels bundle featuring amazing catches, sixes, and memorable moments from the game.",
  },
  {
    id: "emotional",
    name: "Emotional",
    icon: "💧",
    color: "#457B9D",
    description:
      "Heart-touching emotional reels that resonate deeply with audiences and drive massive engagement.",
  },
  {
    id: "spiritual",
    name: "Spiritual & Sanatan",
    icon: "🙏",
    color: "#FF9F1C",
    description:
      "Sanatan (Hindutva) spiritual content reels for devotional and cultural social media pages.",
  },
  {
    id: "business",
    name: "Business & Instagram",
    icon: "📈",
    color: "#06D6A0",
    description:
      "Instagram business motivational posts and reels in Hindi for entrepreneurs and content creators.",
  },
  {
    id: "cartoon",
    name: "Cartoon & Kids",
    icon: "🦈",
    color: "#FFB703",
    description:
      "Fun cartoon reels including Zig & Shark and other kids-friendly animated content.",
  },
  {
    id: "space",
    name: "Space & Science",
    icon: "🚀",
    color: "#3A0CA3",
    description:
      "Space content reels featuring NASA footage, galaxy visuals, and science education content.",
  },
  {
    id: "cats",
    name: "Cats & Pets",
    icon: "🐱",
    color: "#FB8500",
    description:
      "Adorable cat reels and pet content that goes viral on every platform.",
  },
  {
    id: "ai",
    name: "AI Generated",
    icon: "🤖",
    color: "#8338EC",
    description:
      "AI-generated reels and content created with cutting-edge artificial intelligence tools.",
  },
];

export const bundles = [
  {
    id: 1,
    title: "Art And Craft New Update Reels",
    slug: "art-craft-new-update-reels",
    categoryId: "art-craft",
    count: "219",
    downloadUrl:
      "https://drive.google.com/drive/folders/1WCEU7LfIJTh8arWt0hwWnyydZ8nriH48",
    featured: true,
    date: "2025-01-15",
    description:
      "Get 219 brand-new art and craft reels updated recently. These reels feature trending DIY projects, painting techniques, and creative craft ideas that are perfect for Instagram Reels, YouTube Shorts, and TikTok. All content is copyright-free and ready to post.",
    article:
      "If you're looking to grow your art and craft social media page, having fresh, engaging content is essential. This bundle of 219 newly updated art and craft reels includes everything from watercolor painting timelapses to paper crafting tutorials. Each reel is professionally edited and optimized for maximum engagement on platforms like Instagram, YouTube Shorts, and TikTok.\n\nArt and craft content consistently ranks among the most shared categories on social media. Viewers love watching satisfying creative processes, and these reels are designed to capture attention within the first 3 seconds — the critical window for viral content.\n\nWhat's Included:\n• 219 high-quality art and craft reels\n• Mix of painting, drawing, DIY, and craft content\n• Copyright-free — post anywhere without worries\n• Optimized for vertical format (9:16)\n• Ready-to-upload with no additional editing needed\n\nWhether you're a beginner or an established content creator, this bundle saves you hundreds of hours of content creation. Simply download, upload, and watch your engagement grow.",
  },
  {
    id: 2,
    title: "Art High Quality Reels/Shorts Bundle",
    slug: "art-high-quality-reels-shorts",
    categoryId: "art-craft",
    count: "184",
    downloadUrl:
      "https://drive.google.com/drive/folders/1aZkOnDx3yo4KGI6y6db52sm9Wz3Xb_rc",
    featured: false,
    date: "2025-01-10",
    description:
      "184 premium high-quality art reels and shorts. Professional-grade content for art-focused social media pages with stunning visuals and smooth transitions.",
    article:
      "This premium bundle contains 184 high-quality art reels that stand out from typical social media content. Each reel has been carefully curated for visual excellence, featuring smooth transitions, professional color grading, and captivating subject matter.\n\nHigh-quality art content performs significantly better than average posts. Studies show that visually superior reels get 3x more shares and 5x more saves than lower-quality alternatives. This bundle ensures every piece of content you post meets the highest visual standards.\n\nKey Features:\n• 184 premium art reels in full HD\n• Professional transitions and effects\n• Mix of digital art, traditional art, and mixed media\n• Copyright-free for unlimited use\n• Vertical format optimized for all platforms\n\nPerfect for art pages, creative agencies, and anyone who wants their feed to look professionally curated.",
  },
  {
    id: 3,
    title: "Motivational New Update Reels",
    slug: "motivational-new-update-reels",
    categoryId: "motivational",
    count: "800",
    downloadUrl:
      "https://drive.google.com/drive/folders/19L1MMRi0SKG0N0jrRfGbaD6XbMRzfOlg",
    featured: true,
    date: "2025-02-01",
    description:
      "800 brand-new motivational reels freshly updated! The ultimate motivational content bundle for Instagram, YouTube Shorts, and TikTok pages.",
    article:
      "Motivational content is one of the most viral categories on social media, and this massive bundle of 800 new motivational reels gives you an unstoppable content library. From powerful quotes overlaid on stunning visuals to inspiring stories and life lessons, this collection has it all.\n\nWhy Motivational Reels Go Viral:\nMotivational content triggers emotional responses that make people want to share. According to social media analytics, motivational reels get shared 4x more than average content. They also generate significantly more comments and saves, which signals algorithms to push your content to wider audiences.\n\nWhat You'll Get:\n• 800 fresh motivational reels\n• Mix of Hindi and English content\n• Quote reels, story reels, and cinematic motivational content\n• Copyright-free background music included\n• Optimized for all short-form video platforms\n\nThis bundle is perfect for anyone running a motivational page or looking to add inspiring content to their existing feed. With 800 reels, you'll have over 2 years of daily content ready to post.",
  },
  {
    id: 4,
    title: "Islamic New Reels",
    slug: "islamic-new-reels",
    categoryId: "islamic",
    count: "200+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1PMguZKniZCIHbtlp_ESeYiiwxpljEVCk",
    featured: true,
    date: "2025-01-20",
    description:
      "200+ beautiful Islamic reels featuring Quran verses, Islamic reminders, and spiritual content for your Muslim audience.",
    article:
      "Islamic content has a massive and dedicated audience on social media. This bundle of 200+ Islamic reels provides you with high-quality, respectful, and engaging content that resonates with Muslim audiences worldwide.\n\nContent Types Included:\n• Quran verse overlays with beautiful backgrounds\n• Islamic reminders and daily dua content\n• Hadith of the day reels\n• Beautiful masjid and nature Islamic aesthetic reels\n• Ramadan and special occasion content\n\nAll content in this bundle has been created with respect for Islamic values and traditions. The reels feature proper Arabic text, accurate translations, and beautiful visuals that enhance the spiritual message.\n\nWhy Islamic Content Thrives:\nIslamic social media pages see some of the highest engagement rates across all categories. The community is highly active in sharing, saving, and commenting on meaningful content, which helps your posts reach wider audiences organically.",
  },
  {
    id: 5,
    title: "1000+ Emotional New Viral Reels Bundle",
    slug: "emotional-viral-reels-bundle",
    categoryId: "emotional",
    count: "1000+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1HcEoPjIS53WdHsIAe8DzavrIuwmQAQat",
    featured: true,
    date: "2025-02-05",
    description:
      "Massive bundle of 1000+ emotional reels in English that go viral every time. Heart-touching content for maximum engagement.",
    article:
      "Emotional content is the king of virality on social media. This enormous collection of 1000+ emotional reels in English is designed to tug at heartstrings and generate massive engagement across all platforms.\n\nThe Science Behind Emotional Virality:\nResearch shows that content that evokes strong emotions — whether joy, sadness, inspiration, or nostalgia — gets shared 6x more than neutral content. Emotional reels generate more comments, more saves, and more followers than almost any other content type.\n\nWhat's Inside:\n• 1000+ emotional reels in English\n• Mix of heartwarming stories, inspirational moments, and touching scenes\n• Cinematic quality with professional editing\n• Copyright-free for all platforms\n• Organized by emotion type for easy selection\n\nThis is our most comprehensive emotional content bundle ever. With over 1000 reels, you could post 3 times daily for almost a year without repeating content.",
  },
  {
    id: 6,
    title: "Islamic Reels Bundle (Upcoming Collection)",
    slug: "islamic-reels-bundle-upcoming",
    categoryId: "islamic",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1_mzakCsFaDqv-G9c5ZjzgbrXLLp5dbe3",
    featured: false,
    date: "2025-02-10",
    description:
      "Comprehensive Islamic reels bundle with upcoming new content. Includes Quran verses, Islamic reminders, and spiritual reels.",
    article:
      "This Islamic reels bundle combines classic favorites with upcoming new content, giving you a comprehensive library of Islamic social media content. The collection includes 500+ reels covering various aspects of Islamic life and spirituality.\n\nContent Highlights:\n• Quran recitation clips with beautiful visuals\n• Islamic motivational and reminder content\n• Prophet stories and Islamic history reels\n• Daily Islamic wisdom and teachings\n• Beautiful nature scenes with Islamic calligraphy\n\nThis bundle is constantly updated with new content, making it a living library that grows over time. Perfect for Islamic pages looking for a reliable, ongoing source of quality content.",
  },
  {
    id: 7,
    title: "Cricket Reels Bundle",
    slug: "cricket-reels-bundle",
    categoryId: "cricket",
    count: "300+",
    downloadUrl:
      "https://drive.google.com/drive/folders/19ZOdWVrqXqH3G_RGIVDKIQ_THtAv3zao",
    featured: false,
    date: "2025-01-25",
    description:
      "Exciting cricket reels bundle featuring amazing catches, massive sixes, and unforgettable cricket moments from around the world.",
    article:
      "Cricket is more than a sport — it's a passion shared by billions. This cricket reels bundle captures the most thrilling moments from the game, designed to excite cricket fans on your social media pages.\n\nContent Highlights:\n• Spectacular catches and fielding moments\n• Massive sixes and boundary shots\n• Bowler wickets and celebrations\n• Iconic cricket highlights from international matches\n• IPL and T20 league moments\n\nCricket content performs exceptionally well during match seasons and tournaments, but maintains strong engagement year-round. These reels are edited for maximum impact, with slow-motion replays, dramatic music, and dynamic text overlays that capture attention instantly.\n\nPerfect for cricket fan pages, sports pages, and anyone looking to tap into the massive cricket-loving audience on social media.",
  },
  {
    id: 8,
    title: "Art & Craft Reels Collection",
    slug: "art-craft-reels-collection",
    categoryId: "art-craft",
    count: "150+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1uvX4I50ffSWSI4I0391SHuMA87ap8MEL",
    featured: false,
    date: "2025-01-18",
    description:
      "Another fantastic art and craft reels collection with unique creative content including painting, sculpture, and DIY projects.",
    article:
      "This art and craft reels collection offers a different style from our other bundles, with a focus on unique creative techniques and projects that viewers love to watch and share.\n\nWhat Makes This Bundle Special:\n• Focus on trending art techniques and styles\n• Satisfying process videos that viewers can't stop watching\n• Mix of quick DIY projects and detailed artistic processes\n• Seasonal and holiday-themed craft content\n• Beginner-friendly and advanced art techniques\n\nArt process videos are among the most-watched content on social media. The satisfying nature of watching someone create something beautiful keeps viewers engaged and encourages them to share with friends.",
  },
  {
    id: 9,
    title: "500+ AI Reels Bundle (Special)",
    slug: "ai-reels-bundle-special",
    categoryId: "ai",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/17RyytULh5p8pglvW-ehosIq6QiQqitpc",
    featured: true,
    date: "2025-02-08",
    description:
      "Special bundle of 500+ AI-generated reels — the hottest trend in social media content creation. Futuristic and eye-catching!",
    article:
      "AI-generated content is the fastest-growing trend in social media, and this special bundle of 500+ AI reels puts you at the forefront of this revolution. These reels feature stunning AI-created visuals that mesmerize audiences and drive incredible engagement.\n\nWhy AI Content is Exploding:\nAI-generated reels consistently outperform traditional content in terms of watch time and shares. The surreal, otherworldly visuals capture attention like nothing else, and audiences are fascinated by the creative possibilities of artificial intelligence.\n\nBundle Contents:\n• 500+ AI-generated reels in various styles\n• AI art and visual effects reels\n• AI-enhanced motivational content\n• Futuristic and sci-fi themed reels\n• Surreal and dreamlike visual content\n\nAll reels are copyright-free and ready to post on any platform. This is a special collection that combines the best AI-generated content available.",
  },
  {
    id: 10,
    title: "Motivational Shorts and Reels Bundle",
    slug: "motivational-shorts-reels-bundle",
    categoryId: "motivational",
    count: "420+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1Aqiv-rY6MpQMJPD3_MM6jnC7s6TsT2ah",
    featured: false,
    date: "2025-01-28",
    description:
      "420+ motivational shorts and reels curated for maximum engagement. Includes both Hindi and English content.",
    article:
      "This carefully curated bundle of 420+ motivational shorts and reels is designed for content creators who want consistent, high-performing motivational content. Each reel has been selected based on engagement metrics from top-performing pages.\n\nContent Breakdown:\n• Mix of Hindi and English motivational content\n• Quote-based reels with stunning backgrounds\n• Cinematic motivational clips\n• Business and success motivation\n• Life lessons and wisdom content\n\nWith 420+ reels in this bundle, you'll have over a year of content if you post daily. This gives you the freedom to test different posting times and styles while maintaining a consistent presence on your platforms.",
  },
  {
    id: 11,
    title: "WWE Most Popular Bundle",
    slug: "wwe-most-popular-bundle",
    categoryId: "wwe",
    count: "1000",
    downloadUrl:
      "https://drive.google.com/drive/folders/1bAfC0cpqdvocLOdu5gszkCSlv_oZtIPn",
    featured: true,
    date: "2025-02-02",
    description:
      "The ultimate WWE bundle with 1000 viral reels pro templates — the most popular wrestling content collection available!",
    article:
      "WWE content has a massive and passionate audience on social media. This ultimate bundle of 1000 viral WWE reels captures the most iconic moments, epic finishes, and electrifying entrances that wrestling fans can't get enough of.\n\nWhat's Included:\n• 1000 WWE and wrestling reels\n• Iconic match highlights and finishes\n• Superstar entrances and promos\n• Epic moments and shocking returns\n• Championship celebrations and rivalries\n\nWWE content generates incredible engagement because wrestling fans are among the most passionate and active communities on social media. They love sharing, commenting, and debating, which pushes your content to wider audiences organically.\n\nThis is the largest WWE reels bundle available, giving you enough content to post multiple times daily for months.",
  },
  {
    id: 12,
    title: "WWE Most Popular Bundle Part 02",
    slug: "wwe-popular-bundle-part-02",
    categoryId: "wwe",
    count: "1360+",
    downloadUrl:
      "https://drive.google.com/drive/folders/187a-ja5HS16Quki6JnsAxeXJayd4QlOd",
    featured: false,
    date: "2025-02-03",
    description:
      "Part 2 of the WWE bundle with 1360+ motivational reels in English combined with wrestling content for maximum virality.",
    article:
      "The second part of our WWE mega-bundle combines the excitement of wrestling content with powerful motivational messaging. With 1360+ reels, this is our largest single WWE collection.\n\nThis Part 02 collection features:\n• 1360+ reels combining WWE highlights with motivation\n• English language motivational overlays\n• WrestleMania moments and iconic matches\n• Behind-the-scenes and training footage\n• Fighter motivation and determination content\n\nThe combination of WWE action and motivational messaging creates a unique content style that resonates with both wrestling fans and motivation seekers. This crossover appeal significantly expands your potential audience.",
  },
  {
    id: 13,
    title: "WWE Reels Bundle Part 03",
    slug: "wwe-reels-bundle-part-03",
    categoryId: "wwe",
    count: "1365",
    downloadUrl:
      "https://drive.google.com/drive/folders/1Jdbk9dwub5xEhpkvyKHalPNWpWnoOTaU",
    featured: false,
    date: "2025-02-04",
    description:
      "Part 3 of the WWE mega-collection with 1365 viral reels pro templates — complete your wrestling content library!",
    article:
      "Complete your WWE content library with Part 03 of our mega-collection. This bundle adds another 1365 viral reels pro templates to your arsenal, ensuring you never run out of wrestling content.\n\nPart 03 Highlights:\n• 1365 additional WWE reels\n• Viral reels pro templates (1001-1365)\n• Focus on recent wrestling events and superstars\n• Championship moments and rivalry highlights\n• Fan reaction and crowd energy clips\n\nCombined with Parts 01 and 02, this gives you over 3700 WWE reels — the most comprehensive wrestling content library available anywhere. Perfect for dedicated WWE pages and sports content creators.",
  },
  {
    id: 14,
    title: "Hindi Motivational Reels",
    slug: "hindi-motivational-reels",
    categoryId: "motivational",
    count: "100",
    downloadUrl:
      "https://drive.google.com/drive/folders/1GquOL-1HCnCuUy5-Ia667DSVIuZUrfro",
    featured: false,
    date: "2025-01-12",
    description:
      "100 powerful Hindi motivational reels curated for the Hindi-speaking audience. Perfect for Indian social media pages.",
    article:
      "Hindi motivational content has an enormous audience in India and across the Hindi-speaking diaspora. This collection of 100 carefully curated Hindi motivational reels speaks directly to this massive audience.\n\nWhy Hindi Motivational Content Works:\nIndia has over 600 million social media users, and Hindi is the most spoken language. Hindi motivational content generates significantly higher engagement than English content in the Indian market because it feels more personal and relatable.\n\nContent Features:\n• 100 high-quality Hindi motivational reels\n• Powerful quotes from Indian leaders and thinkers\n• Bollywood-inspired motivational content\n• Life lessons and success stories in Hindi\n• Cultural references that resonate with Indian audiences\n\nThese reels are specifically designed for the Indian social media landscape, with cultural nuances and references that English content simply cannot capture.",
  },
  {
    id: 15,
    title: "Mega Cars Reels Bundle",
    slug: "mega-cars-reels-bundle",
    categoryId: "cars",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1f02pqXqhxtlTlDniNll7OVN3QPFnCciR",
    featured: true,
    date: "2025-02-06",
    description:
      "Mega car edits reels bundle with 500+ stunning automotive reels. Supercars, drifts, mods, and more!",
    article:
      "Car content is one of the most engaged-with categories on social media, and this mega bundle of 500+ car edit reels delivers the most stunning automotive content available. From supercar showcases to drifting clips, this collection has everything a car enthusiast could want.\n\nWhat's Inside:\n• 500+ premium car edit reels\n• Supercar showcases (Lamborghini, Ferrari, Porsche, etc.)\n• Drifting and racing content\n• Car modification and tuning reveals\n• Satisfying car wash and detail reels\n• Night drive and aesthetic car content\n\nCar reels perform exceptionally well because they combine visual appeal with aspirational content. People love dreaming about luxury cars, and the satisfying editing style of these reels keeps them watching until the very end.\n\nPerfect for car enthusiast pages, automotive businesses, and anyone looking to tap into the massive car-loving community on social media.",
  },
  {
    id: 16,
    title: "Aesthetic Reels Bundle",
    slug: "aesthetic-reels-bundle",
    categoryId: "aesthetic",
    count: "200+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1abXzzLDuRm_WGrwGz-Zh5O798-JKvJAd",
    featured: false,
    date: "2025-01-22",
    description:
      "Beautiful aesthetic reels bundle with 200+ visually stunning reels for lifestyle and mood-based content creators.",
    article:
      "Aesthetic content has become one of the most popular genres on social media, with entire pages dedicated to creating a specific mood and visual style. This bundle of 200+ aesthetic reels helps you build and maintain that coveted aesthetic feed.\n\nAesthetic Content Styles:\n• Soft and dreamy visual content\n• Moody and atmospheric reels\n• Nature and urban aesthetic shots\n• Coffee, books, and cozy lifestyle reels\n• Sunset, golden hour, and cinematic content\n\nAesthetic pages attract highly engaged followers who are more likely to save, share, and interact with your content. This loyal audience base is valuable for monetization through brand deals and partnerships.\n\nAll reels feature consistent color grading and visual styling, making it easy to maintain a cohesive feed aesthetic.",
  },
  {
    id: 17,
    title: "All Motivation Hindi Bundle",
    slug: "all-motivation-hindi-bundle",
    categoryId: "motivational",
    count: "50",
    downloadUrl:
      "https://drive.google.com/drive/folders/17bEn9rX-248wqZ-Yu1LvqZM1Tpztu2EP",
    featured: false,
    date: "2025-01-08",
    description:
      "50 AI-generated Hindi motivational reels — cutting-edge AI content in Hindi for maximum audience reach.",
    article:
      "This unique bundle combines AI technology with Hindi motivational content, creating 50 AI-generated reels that look professional and capture attention. AI content in Hindi is still relatively rare, giving you a first-mover advantage.\n\nWhy AI Hindi Reels Are Special:\n• Stand out from the crowd with unique AI visuals\n• Hindi text overlays that connect with Indian audiences\n• Professional quality without the production costs\n• Futuristic aesthetic that drives curiosity and engagement\n\nThese 50 reels are perfect for supplementing your existing content strategy. Use them as special posts that generate extra attention and followers, or build an entire AI-themed motivational page around them.",
  },
  {
    id: 18,
    title: "1000+ Anime Reels Bundle",
    slug: "anime-reels-bundle",
    categoryId: "anime",
    count: "1000+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1xJE-N3Oi3VCCMmke82obnC1HQwp3615k",
    featured: true,
    date: "2025-02-12",
    description:
      "Massive 1000+ anime reels bundle featuring viral anime clips, edits, and 2D animation content. The ultimate anime collection!",
    article:
      "Anime content has exploded on social media, and this massive bundle of 1000+ anime reels is the most comprehensive collection available. From viral anime edits to 2D animation clips, this bundle covers every style and genre.\n\nAnime Content Categories:\n• Popular anime fight scenes and epic moments\n• Emotional anime clips and heart-touching scenes\n• Anime edits with trending music\n• AMV (Anime Music Video) style reels\n• 2D animation showcases\n\nAnime has one of the most dedicated fan communities on social media. Anime reels consistently generate high engagement rates, with fans eagerly sharing and commenting on content featuring their favorite characters and series.\n\nWith 1000+ reels, this bundle gives you enough content to run a dedicated anime page for years, or to supplement your existing content strategy with high-performing anime posts.",
  },
  {
    id: 19,
    title: "Best Viral Reels Collection",
    slug: "best-viral-reels-collection",
    categoryId: "motivational",
    count: "300+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1PB0KdatpkM_KJNLgQML82991D05otwie",
    featured: false,
    date: "2025-01-30",
    description:
      "The best viral reels collection — hand-picked content that has proven to go viral across all platforms.",
    article:
      "This collection isn't just any reels bundle — it's a curated selection of content that has already demonstrated viral potential. Each reel in this bundle has been selected based on actual performance metrics from top-performing pages.\n\nWhat Makes These Reels Viral:\n• Strong opening hooks that stop the scroll\n• Emotional triggers that compel sharing\n• Visual patterns that the algorithm favors\n• Trending audio and format alignment\n• Optimal length for maximum completion rate\n\nViral content isn't random — there are patterns and principles that make content shareable. This bundle applies those principles to every single reel, maximizing your chances of hitting the algorithm jackpot.\n\nPerfect for new pages looking to gain initial traction and established pages wanting to boost their reach.",
  },
  {
    id: 20,
    title: "AI Quite Reels",
    slug: "ai-quite-reels",
    categoryId: "ai",
    count: "15",
    downloadUrl:
      "https://drive.google.com/drive/folders/1FNBnfB99cmeAujzgTyIcAChKoUaZO-y6",
    featured: false,
    date: "2025-01-05",
    description:
      "15 premium AI-generated quiet/calm reels with soothing AI visuals. Perfect for mindfulness and relaxation content.",
    article:
      "This boutique collection of 15 AI-generated calm reels offers something unique in the social media landscape — quiet, contemplative content that provides a moment of peace in users' busy feeds.\n\nThe Rise of Calm Content:\nWhile most social media content competes for attention with loud, fast-paced clips, calm content stands out precisely because it's different. Mindfulness and relaxation content has seen a 300% increase in engagement over the past year.\n\nThese AI-generated calm reels feature:\n• Soothing AI-generated landscapes and visuals\n• Slow, meditative motion graphics\n• Minimal and clean aesthetic\n• Perfect for mindfulness and wellness pages\n\nIdeal for wellness pages, mindfulness coaches, and anyone looking to offer their audience a moment of calm among the noise of social media.",
  },
  {
    id: 21,
    title: "Sanatan (Hindutva) Reels",
    slug: "sanatan-hindutva-reels",
    categoryId: "spiritual",
    count: "200+",
    downloadUrl:
      "https://drive.google.com/drive/folders/15XXwGHYr5zXSvpu1z2Bji65rPaN6PQeR",
    featured: false,
    date: "2025-01-14",
    description:
      "Sanatan (Hindutva) spiritual reels featuring Hindu deities, mantras, and devotional content for religious pages.",
    article:
      "Sanatan Dharma content has a deeply devoted audience on social media, and this bundle of 200+ Sanatan (Hindutva) reels provides beautiful, respectful content for religious and spiritual pages.\n\nContent Includes:\n• Beautiful temple and deity visuals\n• Mantra and shloka reels with translations\n• Hindu festival and celebration content\n• Sacred geometry and mandala animations\n• Inspirational content from Hindu scriptures\n\nSanatan content performs exceptionally well during Hindu festivals and auspicious occasions, but maintains strong engagement year-round. Devotional content generates high save rates as users bookmark it for personal reflection and sharing with family groups.\n\nAll content has been created with deep respect for Hindu traditions and spiritual practices.",
  },
  {
    id: 22,
    title: "Instagram Business Motivation Posts",
    slug: "instagram-business-motivation",
    categoryId: "business",
    count: "250+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1dkIJeExJGCDdNf_cB_sBI-uYDmNujGWP",
    featured: true,
    date: "2025-02-07",
    description:
      "Instagram business motivational posts in Hindi from the Dusk Bundle — perfect for entrepreneur and business pages.",
    article:
      "This specialized bundle of Instagram business motivational posts in Hindi is designed specifically for entrepreneur and business-focused pages targeting the Indian market. The Dusk Bundle aesthetic gives these posts a professional, premium feel.\n\nContent Highlights:\n• Business and startup motivation in Hindi\n• Entrepreneur success stories and lessons\n• Sales and marketing tips in reel format\n• Hustle culture and grinding content\n• Professional color schemes and branding\n\nBusiness motivation content attracts a highly valuable audience demographic — entrepreneurs, professionals, and aspiring business owners. This audience is more likely to engage with premium content and is attractive to advertisers and brand partners.\n\nThe Hindi language focus makes this content perfect for the Indian market, where business motivation content is in high demand but quality Hindi options are limited.",
  },
  {
    id: 23,
    title: "All Hindi Reels Bundle",
    slug: "all-hindi-reels-bundle",
    categoryId: "motivational",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/17TZxcANBRfCZQL0G0ZUnIeQ2FyVElq6A",
    featured: false,
    date: "2025-01-26",
    description:
      "500+ AI Hindi reels covering motivation, life lessons, and inspiration — all in Hindi for maximum Indian audience reach.",
    article:
      "This comprehensive bundle of 500+ AI-enhanced Hindi reels covers the full spectrum of motivational and inspirational content, all in Hindi for the massive Indian social media audience.\n\nWhy Hindi Content Matters:\nWith over 600 million Hindi speakers online, Hindi content represents one of the largest untapped opportunities in social media. Pages that post quality Hindi content see significantly higher engagement rates because the audience feels personally connected to the content.\n\nBundle Contents:\n• 500+ Hindi motivational and life lesson reels\n• AI-enhanced visuals with Hindi text overlays\n• Mix of quote reels, story reels, and cinematic content\n• Topics covering success, relationships, health, and more\n• Consistent quality across all reels\n\nThis is the most comprehensive Hindi reels bundle available, giving you enough content for consistent daily posting for over a year and a half.",
  },
  {
    id: 24,
    title: "Fitness Reels Bundle",
    slug: "fitness-reels-bundle",
    categoryId: "fitness",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1ebHNOPHZcMWe1KBetMVFc0YqzXjtHAbh",
    featured: true,
    date: "2025-02-09",
    description:
      "500+ fitness reels for gym, workout, and health pages. Motivating workout content that drives engagement and followers.",
    article:
      "The fitness niche is one of the most profitable categories on social media, and this bundle of 500+ fitness reels gives you everything you need to build or grow a fitness page.\n\nContent Breakdown:\n• Gym workout reels and exercise demonstrations\n• Motivational fitness transformation content\n• Healthy meal prep and nutrition tips\n• Before and after transformation reels\n• Workout challenges and routine videos\n\nFitness pages attract some of the most engaged followers on social media. This audience is motivated, health-conscious, and willing to invest in products and services — making fitness pages highly attractive for brand deals and sponsorships.\n\nWith 500+ reels, you'll have a complete fitness content library that covers every aspect of health and wellness, ensuring your page stays fresh and engaging.",
  },
  {
    id: 25,
    title: "Space Content Reels",
    slug: "space-content-reels",
    categoryId: "space",
    count: "150+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1hpwetf4zqIs1Yt0R0g8dBREDJ_oN61oW",
    featured: false,
    date: "2025-01-16",
    description:
      "Stunning space content reels featuring NASA footage, galaxies, planets, and cosmic visuals for science and education pages.",
    article:
      "Space content captivates audiences like few other categories can. This bundle of 150+ space content reels features breathtaking cosmic visuals that make viewers stop scrolling and stare in wonder.\n\nWhat's Inside:\n• NASA and ESA footage compilations\n• Galaxy and nebula visual reels\n• Planet showcases and cosmic journeys\n• Space exploration milestones\n• Educational space facts and trivia\n\nSpace content has universal appeal — it transcends language, culture, and age barriers. A stunning galaxy reel can go viral in any country, making it perfect for pages targeting global audiences.\n\nThese reels are particularly popular with science, education, and technology pages, but they also perform well on general interest and motivational pages as awe-inspiring interludes.",
  },
  {
    id: 26,
    title: "Car Reels Collection",
    slug: "car-reels-collection",
    categoryId: "cars",
    count: "200+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1sDrsT8RnCKR6uLR3oczZmAlT3jwAAoYW",
    featured: false,
    date: "2025-01-19",
    description:
      "200+ car reels featuring luxury vehicles, supercars, and automotive content that car enthusiasts love to share.",
    article:
      "This additional car reels collection of 200+ reels complements our Mega Cars bundle with different styles and content types, giving you even more variety for your automotive social media page.\n\nCollection Highlights:\n• Luxury car showcases and reviews\n• Classic and vintage car content\n• Car culture and meet-up reels\n• Automotive photography and cinematography\n• Road trip and driving experience reels\n\nCar content is evergreen — it performs well regardless of season or current trends. Car enthusiasts are among the most loyal followers on social media, providing consistent engagement and share activity that helps your content reach new audiences.",
  },
  {
    id: 27,
    title: "Zig & Shark Cartoon Reels",
    slug: "zig-shark-cartoon-reels",
    categoryId: "cartoon",
    count: "150+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1sJmwRYH5l4fyGQaUPJ1MfvwwJT5PkL4h",
    featured: false,
    date: "2025-01-21",
    description:
      "Zig & Shark cartoon reels bundle — fun animated content that kids and families love to watch and share.",
    article:
      "Cartoon content has a unique advantage on social media — it appeals to both children and adults who enjoy nostalgic, funny animated content. This Zig & Shark cartoon reels bundle provides entertaining content that the whole family can enjoy.\n\nWhy Cartoon Content Works:\n• Appeals to a broad age range\n• High share rate as parents share with kids\n• Nostalgia factor for adult viewers\n• Safe, family-friendly content that platforms favor\n• Consistently high completion rates\n\nThese Zig & Shark reels are professionally edited with engaging transitions and trending audio, making them perfect for kids' content pages, family-oriented pages, and anyone looking to add some fun, lighthearted content to their feed.",
  },
  {
    id: 28,
    title: "2D Animation Reels Bundle",
    slug: "2d-animation-reels-bundle",
    categoryId: "anime",
    count: "300+",
    downloadUrl:
      "https://drive.google.com/drive/folders/15eCPxYfopl1kZzm2VyVqggdtYcCq6LNP",
    featured: false,
    date: "2025-01-23",
    description:
      "300+ 2D animation reels featuring stunning animated content from various styles and genres. Perfect for animation lovers.",
    article:
      "2D animation has experienced a massive resurgence on social media, with animated shorts and reels going viral regularly. This bundle of 300+ 2D animation reels showcases the best of various animation styles and genres.\n\nAnimation Styles Included:\n• Hand-drawn style animations\n• Digital 2D animation clips\n• Anime-style short animations\n• Motion graphics and kinetic typography\n• Character animation and storytelling reels\n\n2D animation reels stand out in social media feeds because they look different from typical video content. This visual distinction helps stop the scroll and encourages viewers to watch until the end, boosting your algorithm ranking.\n\nPerfect for animation pages, art pages, and anyone looking to diversify their content with unique, eye-catching animated reels.",
  },
  {
    id: 29,
    title: "English Motivation Reels",
    slug: "english-motivation-reels",
    categoryId: "motivational",
    count: "70",
    downloadUrl:
      "https://drive.google.com/drive/folders/12mlzZqUhMeSvpO_HcfpSOGShZs2YUXit",
    featured: false,
    date: "2025-01-07",
    description:
      "70 premium English motivational reels with powerful quotes and cinematic visuals for global audience reach.",
    article:
      "This focused collection of 70 premium English motivational reels delivers high-impact content for a global audience. Each reel has been crafted for maximum emotional impact and shareability.\n\nWhy Quality Over Quantity:\nWhile larger bundles offer volume, this curated collection of 70 reels focuses on quality. Each reel has been individually selected and optimized for performance, ensuring that every post you make has the potential to go viral.\n\nContent Features:\n• Powerful motivational quotes in English\n• Cinematic background footage\n• Professional text animations and transitions\n• Optimized for global English-speaking audiences\n• Mix of success, perseverance, and mindset content\n\nThese 70 reels are perfect for new pages looking to establish a strong foundation, or for established pages wanting to add premium English motivational content to their rotation.",
  },
  {
    id: 30,
    title: "Motivation Reels Classic Collection",
    slug: "motivation-reels-classic",
    categoryId: "motivational",
    count: "100+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1EEy77Jb5Wh5Eza8-35WtnIJlJhM_IEG4",
    featured: false,
    date: "2024-12-20",
    description:
      "Classic motivation reels collection with timeless motivational content that continues to perform well across all platforms.",
    article:
      "This classic motivation reels collection contains timeless content that has consistently performed well across social media platforms. Unlike trending content that fades quickly, these reels feature universal motivational themes that remain relevant regardless of current trends.\n\nTimeless Content Advantages:\n• Consistent engagement regardless of trends\n• Can be posted anytime without feeling dated\n• Universal themes that appeal across demographics\n• Evergreen motivational messages\n• Reliable performance metrics\n\nThe classic collection includes motivational content focused on perseverance, success, discipline, and personal growth — themes that never go out of style. This makes it a reliable foundation for any motivational content strategy.",
  },
  {
    id: 31,
    title: "Cat Reels & Shorts",
    slug: "cat-reels-shorts",
    categoryId: "cats",
    count: "200+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1_mzakCsFaDqv-G9c5ZjzgbrXLLp5dbe3",
    featured: false,
    date: "2025-01-11",
    description:
      "Adorable cat reels and shorts that melt hearts and go viral. The internet loves cats, and these reels prove it!",
    article:
      "The internet's love affair with cats is well-documented, and this bundle of 200+ cat reels and shorts delivers the adorable content that drives massive engagement. From funny cat moments to cute kitten videos, this collection has everything cat lovers crave.\n\nWhy Cat Content Dominates:\nCat content generates some of the highest engagement rates across all social media platforms. People can't resist sharing cute and funny cat videos, which makes them perfect for growing your page organically.\n\nWhat's Included:\n• 200+ cat and kitten reels\n• Funny cat moments and fails\n• Cute kitten compilations\n• Cat behavior and personality reels\n• Cat and owner bonding content\n\nCat content is universal — it transcends language and cultural barriers, making it perfect for pages targeting global audiences. These reels are guaranteed to generate smiles and shares.",
  },
  {
    id: 32,
    title: "Islamic Reels Mega Bundle",
    slug: "islamic-reels-mega-bundle",
    categoryId: "islamic",
    count: "500+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1_mzakCsFaDqv-G9c5ZjzgbrXLLp5dbe3",
    featured: true,
    date: "2025-02-11",
    description:
      "Islamic reels mega bundle — the most comprehensive Islamic content collection with Quran, Hadith, and spiritual reels.",
    article:
      "This Islamic reels mega bundle is the most comprehensive Islamic content collection available, featuring 500+ reels covering every aspect of Islamic life and spirituality.\n\nComprehensive Coverage:\n• Quran recitation with beautiful visuals\n• Hadith of the day and Islamic wisdom\n• Prophet stories and Islamic history\n• Duas and supplications\n• Ramadan, Eid, and special occasion content\n• Islamic calligraphy and art reels\n• Mosque and Islamic architecture\n\nIslamic content pages are among the most engaged communities on social media. The Muslim audience actively seeks out, shares, and saves Islamic content, creating a strong organic distribution network for your posts.\n\nThis mega bundle ensures you have content for every occasion, from daily posts to special Islamic events and celebrations throughout the year.",
  },
  {
    id: 33,
    title: "2D Shorts Videos Reels",
    slug: "2d-shorts-videos-reels",
    categoryId: "anime",
    count: "100+",
    downloadUrl:
      "https://drive.google.com/drive/folders/1EdlOBYKuYl1CITGIIgAAyS32DYE2v8VZ",
    featured: false,
    date: "2025-01-24",
    description:
      "100+ 2D short video reels featuring vibrant animation styles perfect for YouTube Shorts and Instagram Reels.",
    article:
      "This collection of 100+ 2D short video reels focuses on the short-form format that dominates social media today. Each reel is optimized for YouTube Shorts and Instagram Reels, with maximum visual impact in minimum time.\n\nShort-Form 2D Animation Advantages:\n• Perfect length for maximum completion rate\n• Quick visual hooks that stop the scroll\n• Shareable across all platforms\n• Eye-catching animation that stands out\n• Works well with trending audio\n\n2D animation shorts have a unique visual appeal that makes them stand out in feeds dominated by live-action content. This visual distinctiveness is a major advantage in the competitive social media landscape.\n\nThese reels are ready to post with no additional editing needed, though they also work great as bases for adding your own text overlays and branding.",
  },
];

export const getBundleBySlug = (slug) => bundles.find((b) => b.slug === slug);
export const getBundlesByCategory = (categoryId) =>
  bundles.filter((b) => b.categoryId === categoryId);
export const getCategoryById = (id) => categories.find((c) => c.id === id);
export const getFeaturedBundles = () => bundles.filter((b) => b.featured);
