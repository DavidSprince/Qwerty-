import { useParams, Link } from "react-router-dom";
import {
  Download,
  Clock,
  Tag,
  Share2,
  ArrowLeft,
  FolderOpen,
  AlertCircle,
} from "lucide-react";
import { getBundleBySlug, getCategoryById, bundles } from "../data/bundles";
import AdPlaceholder from "../components/AdPlaceholder";
import BundleCard from "../components/BundleCard";

export default function BundlePage() {
  const { slug } = useParams();
  const bundle = getBundleBySlug(slug);

  if (!bundle) {
    return (
      <div className="page">
        <div className="container">
          <div className="no-results">
            <h3>Bundle not found</h3>
            <p>The bundle you're looking for doesn't exist.</p>
            <Link to="/bundles" className="btn btn-primary">
              Browse All Bundles
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const category = getCategoryById(bundle.categoryId);
  const relatedBundles = bundles
    .filter((b) => b.categoryId === bundle.categoryId && b.id !== bundle.id)
    .slice(0, 3);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: bundle.title,
        text: bundle.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  return (
    <div className="page">
      {/* Breadcrumb */}
      <div className="breadcrumb-bar">
        <div className="container">
          <nav className="breadcrumb">
            <Link to="/">Home</Link>
            <span>/</span>
            <Link to="/categories">Categories</Link>
            <span>/</span>
            <Link to={`/category/${category.id}`}>{category.name}</Link>
            <span>/</span>
            <span className="breadcrumb-current">{bundle.title}</span>
          </nav>
        </div>
      </div>

      <div className="container">
        <div className="bundle-page-layout">
          {/* Main Content */}
          <main className="bundle-page-main">
            <article className="bundle-article">
              {/* Header */}
              <div className="bundle-article-header">
                <div className="bundle-article-meta">
                  <span
                    className="bundle-article-category"
                    style={{ color: category.color }}
                  >
                    <Tag size={14} /> {category.icon} {category.name}
                  </span>
                  <span className="bundle-article-date">
                    <Clock size={14} />{" "}
                    {new Date(bundle.date).toLocaleDateString("en-US", {
                      month: "long",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                  <button className="share-btn" onClick={handleShare}>
                    <Share2 size={14} /> Share
                  </button>
                </div>
                <h1>{bundle.title}</h1>
                <div className="bundle-article-badge">
                  <span className="count-badge">
                    <FolderOpen size={16} /> {bundle.count} Reels
                  </span>
                  <span className="free-badge">✓ Free Download</span>
                  <span className="copyright-badge">
                    ✓ Copyright Free
                  </span>
                </div>
              </div>

              {/* Banner Image */}
              <div
                className="bundle-article-banner"
                style={{
                  background: `linear-gradient(135deg, ${category.color}cc, ${category.color}66)`,
                }}
              >
                <span className="bundle-article-banner-icon">
                  {category.icon}
                </span>
                <h2>{bundle.count}+ {category.name} Reels</h2>
                <p>Ready to download • Copyright free • Instant access</p>
              </div>

              {/* Description */}
              <div className="bundle-article-intro">
                <p className="lead">{bundle.description}</p>
              </div>

              {/* In-Article Ad */}
              <AdPlaceholder slot="inArticle" />

              {/* Full Article */}
              <div className="bundle-article-body">
                {bundle.article.split("\n\n").map((paragraph, i) => {
                  if (paragraph.startsWith("•") || paragraph.includes("\n•")) {
                    const lines = paragraph.split("\n");
                    return (
                      <div key={i} className="article-list">
                        {lines.map((line, j) => (
                          <div key={j} className="article-list-item">
                            {line.replace("• ", "")}
                          </div>
                        ))}
                      </div>
                    );
                  }
                  if (paragraph.endsWith(":")) {
                    return (
                      <h3 key={i} className="article-subheading">
                        {paragraph}
                      </h3>
                    );
                  }
                  if (
                    paragraph.length < 60 &&
                    !paragraph.endsWith(".") &&
                    !paragraph.endsWith("!")
                  ) {
                    return (
                      <h3 key={i} className="article-subheading">
                        {paragraph}
                      </h3>
                    );
                  }
                  return <p key={i}>{paragraph}</p>;
                })}
              </div>

              {/* Download Section */}
              <div className="download-section">
                <div className="download-box">
                  <h3>📥 Download {bundle.title}</h3>
                  <p>
                    Click the button below to access the Google Drive folder
                    containing all {bundle.count} reels. No registration
                    required!
                  </p>
                  <a
                    href={bundle.downloadUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-download btn-lg btn-block"
                  >
                    <Download size={22} /> Download {bundle.count}+ Reels from
                    Google Drive
                  </a>
                  <div className="download-note">
                    <AlertCircle size={14} />
                    <span>
                      This will open Google Drive in a new tab. You can download
                      individual reels or the entire folder. All content is
                      copyright-free.
                    </span>
                  </div>
                </div>
              </div>

              {/* Second In-Article Ad */}
              <AdPlaceholder slot="inArticle" style={{ marginTop: "2rem" }} />

              {/* How to Use Section */}
              <div className="how-to-section">
                <h3>📋 How to Use These Reels</h3>
                <div className="how-to-steps">
                  <div className="how-to-step">
                    <div className="step-number">1</div>
                    <div>
                      <h4>Download the Bundle</h4>
                      <p>
                        Click the download button above to access the Google
                        Drive folder. Download all files or select specific
                        reels.
                      </p>
                    </div>
                  </div>
                  <div className="how-to-step">
                    <div className="step-number">2</div>
                    <div>
                      <h4>Customize (Optional)</h4>
                      <p>
                        Add your branding, text overlays, or edit the reels to
                        match your style. Many creators post them as-is for
                        quick results.
                      </p>
                    </div>
                  </div>
                  <div className="how-to-step">
                    <div className="step-number">3</div>
                    <div>
                      <h4>Upload & Post</h4>
                      <p>
                        Upload to Instagram Reels, YouTube Shorts, TikTok, or
                        Facebook Reels. All content is copyright-free and ready
                        to post.
                      </p>
                    </div>
                  </div>
                  <div className="how-to-step">
                    <div className="step-number">4</div>
                    <div>
                      <h4>Watch Your Page Grow</h4>
                      <p>
                        Post consistently and watch your engagement and
                        followers grow organically. Consistency is the key to
                        social media success!
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </main>

          {/* Sidebar */}
          <aside className="bundle-page-sidebar">
            {/* Sidebar Download Card */}
            <div className="sidebar-download-card">
              <div
                className="sidebar-card-header"
                style={{ background: category.color }}
              >
                <span>{category.icon}</span>
                <strong>{bundle.count}+ Reels</strong>
              </div>
              <div className="sidebar-card-body">
                <h4>{bundle.title}</h4>
                <ul className="sidebar-features">
                  <li>✓ Copyright Free</li>
                  <li>✓ Instant Download</li>
                  <li>✓ Google Drive Access</li>
                  <li>✓ No Registration</li>
                  <li>✓ All Formats Ready</li>
                </ul>
                <a
                  href={bundle.downloadUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-download btn-block"
                >
                  <Download size={18} /> Free Download
                </a>
              </div>
            </div>

            {/* Sidebar Ad */}
            <AdPlaceholder slot="sidebar" />

            {/* Related Bundles */}
            {relatedBundles.length > 0 && (
              <div className="sidebar-related">
                <h4>Related Bundles</h4>
                {relatedBundles.map((rb) => (
                  <Link
                    key={rb.id}
                    to={`/bundle/${rb.slug}`}
                    className="sidebar-related-item"
                  >
                    <span className="sidebar-related-icon">
                      {getCategoryById(rb.categoryId).icon}
                    </span>
                    <div>
                      <strong>{rb.title}</strong>
                      <span>{rb.count} reels</span>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {/* Telegram CTA */}
            <div className="sidebar-telegram">
              <h4>📱 Get More Bundles</h4>
              <p>Join our Telegram for exclusive content</p>
              <a
                href="https://t.me/bekingvipu"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-telegram btn-block btn-sm"
              >
                Join Telegram
              </a>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
