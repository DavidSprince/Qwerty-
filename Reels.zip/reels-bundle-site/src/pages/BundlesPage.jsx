import { useState, useMemo } from "react";
import { bundles, categories, getCategoryById } from "../data/bundles";
import BundleCard from "../components/BundleCard";
import AdPlaceholder from "../components/AdPlaceholder";

export default function BundlesPage({ searchQuery = "" }) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("newest");

  const filteredBundles = useMemo(() => {
    let result = [...bundles];

    if (selectedCategory !== "all") {
      result = result.filter((b) => b.categoryId === selectedCategory);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.description.toLowerCase().includes(q) ||
          getCategoryById(b.categoryId).name.toLowerCase().includes(q)
      );
    }

    switch (sortBy) {
      case "newest":
        result.sort((a, b) => new Date(b.date) - new Date(a.date));
        break;
      case "oldest":
        result.sort((a, b) => new Date(a.date) - new Date(b.date));
        break;
      case "count":
        result.sort((a, b) => {
          const numA = parseInt(a.count.replace(/[^0-9]/g, "")) || 0;
          const numB = parseInt(b.count.replace(/[^0-9]/g, "")) || 0;
          return numB - numA;
        });
        break;
      default:
        break;
    }

    return result;
  }, [selectedCategory, sortBy, searchQuery]);

  return (
    <div className="page">
      <div className="page-hero">
        <div className="container">
          <h1>All Bundles</h1>
          <p>
            Browse our complete collection of {bundles.length} free download
            bundles
          </p>
        </div>
      </div>

      <div className="container">
        <div className="filters-bar">
          <div className="filter-group">
            <label>Category:</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">All Categories</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.icon} {cat.name}
                </option>
              ))}
            </select>
          </div>
          <div className="filter-group">
            <label>Sort by:</label>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="count">Most Reels</option>
            </select>
          </div>
          <div className="filter-results">
            Showing {filteredBundles.length} bundle
            {filteredBundles.length !== 1 ? "s" : ""}
          </div>
        </div>

        <AdPlaceholder slot="horizontal" />

        {filteredBundles.length === 0 ? (
          <div className="no-results">
            <h3>No bundles found</h3>
            <p>Try adjusting your filters or search query</p>
          </div>
        ) : (
          <div className="bundles-grid">
            {filteredBundles.map((bundle) => (
              <BundleCard key={bundle.id} bundle={bundle} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
