import { categories, getBundlesByCategory } from "../data/bundles";
import CategoryCard from "../components/CategoryCard";

export default function CategoriesPage() {
  return (
    <div className="page">
      <div className="page-hero">
        <div className="container">
          <h1>Browse Categories</h1>
          <p>
            Explore our collection of {categories.length} categories covering
            every type of social media content you need
          </p>
        </div>
      </div>
      <div className="container">
        <div className="categories-list-page">
          {categories.map((cat) => {
            const bundleCount = getBundlesByCategory(cat.id).length;
            const totalReels = getBundlesByCategory(cat.id).reduce(
              (acc, b) => {
                const num = parseInt(b.count.replace(/[^0-9]/g, ""));
                return acc + (isNaN(num) ? 0 : num);
              },
              0
            );
            return (
              <div key={cat.id} className="category-list-item">
                <div
                  className="category-list-icon"
                  style={{ background: `${cat.color}22`, color: cat.color }}
                >
                  <span>{cat.icon}</span>
                </div>
                <div className="category-list-info">
                  <h3>{cat.name}</h3>
                  <p>{cat.description}</p>
                  <div className="category-list-stats">
                    <span>{bundleCount} bundle{bundleCount !== 1 ? "s" : ""}</span>
                    <span>•</span>
                    <span>{totalReels.toLocaleString()}+ reels</span>
                  </div>
                </div>
                <a href={`/category/${cat.id}`} className="btn btn-primary btn-sm">
                  View Bundles
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
