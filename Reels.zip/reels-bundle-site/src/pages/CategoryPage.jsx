import { useParams, Link } from "react-router-dom";
import {
  categories,
  getBundlesByCategory,
  getCategoryById,
} from "../data/bundles";
import BundleCard from "../components/BundleCard";
import AdPlaceholder from "../components/AdPlaceholder";

export default function CategoryPage() {
  const { id } = useParams();
  const category = getCategoryById(id);
  const bundles = getBundlesByCategory(id);

  if (!category) {
    return (
      <div className="page">
        <div className="container">
          <div className="no-results">
            <h3>Category not found</h3>
            <p>The category you're looking for doesn't exist.</p>
            <Link to="/categories" className="btn btn-primary">
              Browse Categories
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const totalReels = bundles.reduce((acc, b) => {
    const num = parseInt(b.count.replace(/[^0-9]/g, ""));
    return acc + (isNaN(num) ? 0 : num);
  }, 0);

  return (
    <div className="page">
      <div
        className="page-hero category-hero"
        style={{
          background: `linear-gradient(135deg, ${category.color}33, ${category.color}11)`,
        }}
      >
        <div className="container">
          <span className="category-hero-icon">{category.icon}</span>
          <h1>{category.name} Reels Bundles</h1>
          <p>{category.description}</p>
          <div className="category-hero-stats">
            <span>{bundles.length} bundles</span>
            <span>•</span>
            <span>{totalReels.toLocaleString()}+ total reels</span>
          </div>
        </div>
      </div>

      <div className="container">
        <AdPlaceholder slot="horizontal" />

        {/* Article about the category */}
        <article className="category-article">
          <h2>About {category.name} Reels</h2>
          <div className="article-content">
            <p>
              Our {category.name.toLowerCase()} reels collection is one of the
              most comprehensive available online. Whether you're running a
              dedicated {category.name.toLowerCase()} page or looking to add{" "}
              {category.name.toLowerCase()} content to your existing social media
              strategy, these bundles provide everything you need.
            </p>
            <p>
              All {category.name.toLowerCase()} reels in our collection are
              copyright-free, meaning you can post them on Instagram, YouTube
              Shorts, TikTok, Facebook Reels, and any other platform without
              worrying about content strikes or takedowns. Each bundle is
              carefully curated for quality and engagement potential.
            </p>
            <p>
              {category.name} content consistently ranks among the
              highest-engagement categories on social media. By posting quality{" "}
              {category.name.toLowerCase()} reels regularly, you can grow your
              following organically and build a loyal audience that looks forward
              to your content every day.
            </p>
          </div>
        </article>

        <div className="bundles-grid">
          {bundles.map((bundle) => (
            <BundleCard key={bundle.id} bundle={bundle} />
          ))}
        </div>

        <AdPlaceholder slot="inFeed" />

        {/* Related Categories */}
        <section className="related-categories">
          <h3>Explore Other Categories</h3>
          <div className="related-cats-grid">
            {categories
              .filter((c) => c.id !== id)
              .slice(0, 6)
              .map((cat) => (
                <Link
                  key={cat.id}
                  to={`/category/${cat.id}`}
                  className="related-cat-card"
                >
                  <span className="related-cat-icon">{cat.icon}</span>
                  <span className="related-cat-name">{cat.name}</span>
                </Link>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
}
