import { Link } from "react-router-dom";
import {
  Download,
  Shield,
  Zap,
  TrendingUp,
  ArrowRight,
  Star,
} from "lucide-react";
import { categories, getFeaturedBundles } from "../data/bundles";
import BundleCard from "../components/BundleCard";
import CategoryCard from "../components/CategoryCard";
import AdPlaceholder from "../components/AdPlaceholder";

export default function HomePage() {
  const featured = getFeaturedBundles();

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-bg-shapes">
          <div className="shape shape-1"></div>
          <div className="shape shape-2"></div>
          <div className="shape shape-3"></div>
        </div>
        <div className="hero-content">
          <div className="hero-badge">
            <Star size={14} /> #1 Free Reels Bundle Platform
          </div>
          <h1>
            Copyright-Free <span className="gradient-text">Reels Bundles</span>{" "}
            for Every Creator
          </h1>
          <p className="hero-sub">
            Download 10,000+ ready-to-post Instagram Reels, YouTube Shorts &
            TikTok videos. Motivational, Islamic, Anime, Cars, Fitness & more.
            All free. All copyright-free.
          </p>
          <div className="hero-actions">
            <Link to="/bundles" className="btn btn-primary btn-lg">
              <Download size={20} /> Browse All Bundles
            </Link>
            <Link to="/categories" className="btn btn-outline btn-lg">
              View Categories <ArrowRight size={18} />
            </Link>
          </div>
          <div className="hero-stats">
            <div className="stat">
              <strong>33+</strong>
              <span>Bundles</span>
            </div>
            <div className="stat">
              <strong>10,000+</strong>
              <span>Total Reels</span>
            </div>
            <div className="stat">
              <strong>15</strong>
              <span>Categories</span>
            </div>
            <div className="stat">
              <strong>100%</strong>
              <span>Free</span>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Banner */}
      <div className="container">
        <AdPlaceholder slot="horizontal" />
      </div>

      {/* Why Choose Us */}
      <section className="features-section">
        <div className="container">
          <div className="section-header">
            <h2>Why Choose ReelsBundle?</h2>
            <p>Everything you need to grow your social media pages</p>
          </div>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <Shield size={28} />
              </div>
              <h3>100% Copyright Free</h3>
              <p>
                Every reel is copyright-free. Post on any platform without
                worrying about strikes or takedowns.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">
                <Zap size={28} />
              </div>
              <h3>Instant Download</h3>
              <p>
                Download entire bundles instantly via Google Drive. No
                registration, no payment, no waiting.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">
                <TrendingUp size={28} />
              </div>
              <h3>Viral-Ready Content</h3>
              <p>
                Reels curated and edited for maximum engagement. Hooks, pacing,
                and effects optimized for algorithms.
              </p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">
                <Download size={28} />
              </div>
              <h3>Regular Updates</h3>
              <p>
                New bundles added regularly. Join our Telegram for early access
                and exclusive content drops.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="categories-section">
        <div className="container">
          <div className="section-header">
            <h2>Browse by Category</h2>
            <p>Find the perfect reels for your niche</p>
          </div>
          <div className="categories-grid">
            {categories.map((cat) => (
              <CategoryCard key={cat.id} category={cat} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Bundles */}
      <section className="featured-section">
        <div className="container">
          <div className="section-header">
            <h2>⭐ Featured Bundles</h2>
            <p>Our most popular and highest-rated bundles</p>
          </div>
          <div className="bundles-grid">
            {featured.map((bundle) => (
              <BundleCard key={bundle.id} bundle={bundle} />
            ))}
          </div>
          <div className="section-cta">
            <Link to="/bundles" className="btn btn-primary btn-lg">
              View All Bundles <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* In-Feed Ad */}
      <div className="container">
        <AdPlaceholder slot="inFeed" />
      </div>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <div className="cta-box">
            <h2>📱 Join Our Telegram Channel</h2>
            <p>
              Get exclusive bundles, early access to new content, and connect
              with thousands of content creators. Be the first to know when new
              bundles drop!
            </p>
            <a
              href="https://t.me/bekingvipu"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-telegram btn-lg"
            >
              Join Be KING on Telegram
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
