import { useMemo } from "react";
import { bundles, getCategoryById } from "../data/bundles";
import BundleCard from "../components/BundleCard";

export default function SearchPage({ query }) {
  const results = useMemo(() => {
    if (!query) return [];
    const q = query.toLowerCase();
    return bundles.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.description.toLowerCase().includes(q) ||
        getCategoryById(b.categoryId).name.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="page">
      <div className="page-hero">
        <div className="container">
          <h1>Search Results</h1>
          <p>
            {results.length} result{results.length !== 1 ? "s" : ""} for "
            {query}"
          </p>
        </div>
      </div>
      <div className="container">
        {results.length === 0 ? (
          <div className="no-results">
            <h3>No results found</h3>
            <p>Try a different search term</p>
          </div>
        ) : (
          <div className="bundles-grid">
            {results.map((bundle) => (
              <BundleCard key={bundle.id} bundle={bundle} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
